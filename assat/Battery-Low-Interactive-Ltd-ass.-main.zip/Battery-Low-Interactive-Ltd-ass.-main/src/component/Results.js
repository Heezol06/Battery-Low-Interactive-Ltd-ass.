import React from 'react';

const Results = () => {
    return (
        <div>
            this is results page
        </div>
    );
};

export default Results;